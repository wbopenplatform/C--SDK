// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TXAPITool.h"
#include "LoginDlg.h"
#include <string>
#include "..\Include\WeiboParam.h"
#include "inputdlg.h"
#include "Util.h"
using namespace std;

// CLoginDlg dialog


CStringA GetModulePath(void)
{
	char sExeFullPath[MAX_PATH];
	memset(sExeFullPath,0,MAX_PATH);

	int nLen = GetModuleFileNameA(NULL, sExeFullPath,MAX_PATH);
	CStringA strPath(sExeFullPath);
	strPath = strPath.Left(strPath.ReverseFind('\\'));
	return strPath;
}

#define CONFIG_PATH (GetModulePath() + "\\APITool.ini")

IMPLEMENT_DYNAMIC(CLoginDlg, CDialog)

CLoginDlg::CLoginDlg(CWnd* pParent /*=NULL*/)
: CDialog(CLoginDlg::IDD, pParent)
{
}

CLoginDlg::~CLoginDlg()
{
}

void CLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_APPKEY, m_editAppKey);
	DDX_Control(pDX, IDC_APPSECRET, m_editAppSecret);
	DDX_Control(pDX, IDC_APPSECRET2, m_editCallbackUrl);
}


BEGIN_MESSAGE_MAP(CLoginDlg, CDialog)
	ON_BN_CLICKED(IDC_LOGIN, &CLoginDlg::OnBnClickedLogin)
	ON_BN_CLICKED(IDC_CANCEL, &CLoginDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CLoginDlg message handlers

void CLoginDlg::OnBnClickedLogin()
{
	CString strInputAppKey;
	m_editAppKey.GetWindowText(strInputAppKey);

	CString strInputAppSecret;
	m_editAppSecret.GetWindowText(strInputAppSecret);

	CString strInputCallbackUrl;
	m_editCallbackUrl.GetWindowText(strInputCallbackUrl);


	if(strInputAppKey.IsEmpty())
	{
		MessageBox(L"AppKey����Ϊ��");
		return ;
	}
	if(strInputAppSecret.IsEmpty())
	{
		MessageBox(L"AppSecret����Ϊ��");
		return ;
	}
	if(strInputCallbackUrl.IsEmpty())
	{
		MessageBox(L"CallbackUrl����Ϊ��");
		return ;
	}

	if((Unicode2Mbcs(strInputAppKey.GetString()) != m_sstrAppKey)
		||(Unicode2Mbcs(strInputAppSecret.GetString()) != m_sstrAppSecret)
		||(Unicode2Mbcs(strInputCallbackUrl.GetString()) != m_sstrCallBackUrl))   
	{
		m_sstrAccessKey.clear();

        m_sstrAppKey = Unicode2Mbcs(strInputAppKey.GetString());
        m_sstrAppSecret = Unicode2Mbcs(strInputAppSecret.GetString());
		m_sstrCallBackUrl = Unicode2Mbcs(strInputCallbackUrl.GetString());

		if(m_sstrCallBackUrl.find("http://", 0) == std::string::npos)
		{
			std::string strTmp = "http://";
			strTmp.append(m_sstrCallBackUrl);
			m_sstrCallBackUrl = strTmp;
		}
		//��ȡtokenkey����ҳ
		if(GetCode() == FALSE)
		{
			MessageBox(L"��ȡtoken key����");
			return ;
		}

	}
	else if(m_sstrAccessKey.empty())
	{
		//��ȡcode����ҳ
		if(GetCode() == FALSE)
		{
			MessageBox(L"��ȡtoken key����");
			return ;
		}
	}

	if(m_sstrAccessKey.empty())
	{
		CInputDlg dlg;//�õ�oauth_verifier
		if(dlg.DoModal() != IDOK)
		{
			return;
		}

		m_sstrCode = Unicode2Mbcs(dlg.m_strCode.GetString());
		m_sstrOpenid = Unicode2Mbcs(dlg.m_strOpenid.GetString());

		if(GetAccessKey() != TRUE)
		{
			MessageBox(L"��ȡaccess key����");
			return ;
		}
	}
	//���������ļ�·��Ϊ��ǰexe��Ŀ¼,��Ϣ��Ϊ����
	::WritePrivateProfileStringA("Config","AppKey",m_sstrAppKey.c_str(),CONFIG_PATH);
	::WritePrivateProfileStringA("Config","AppSecret",m_sstrAppSecret.c_str(),CONFIG_PATH);
	::WritePrivateProfileStringA("Config","AccessKey",m_sstrAccessKey.c_str(),CONFIG_PATH);
	::WritePrivateProfileStringA("Config","Openid",m_sstrOpenid.c_str(),CONFIG_PATH);
	::WritePrivateProfileStringA("Config","CallbackUrl",m_sstrCallBackUrl.c_str(),CONFIG_PATH);
	OnOK();
}

void CLoginDlg::OnBnClickedCancel()
{
	OnCancel();
}

BOOL CLoginDlg::GetCode()
{
	CWeiboParam oParam;

	std::string c_strCustomKey		= TXWeibo::Param::strCustomKey;
	std::string c_oauthCallback		= TXWeibo::Param::strCallbackUrl;
	std::string c_resonseType		= TXWeibo::Param::strRespType;

	string strUrl = "https://open.t.qq.com/cgi-bin/oauth2/authorize";
	strUrl += "?redirect_uri=";
	strUrl += m_sstrCallBackUrl;

	strUrl += "&response_type=code";
	strUrl += "&client_id=";
	strUrl += m_sstrAppKey;

	ShellExecuteA( NULL, "open", strUrl.c_str(), NULL, NULL, SW_SHOWNORMAL); 
	return TRUE;
}

BOOL CLoginDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	//��ȡ�����ļ� 
	char szConfig[1024];
	ZeroMemory(szConfig,1024*sizeof(char));
	::GetPrivateProfileStringA("Config","AppKey","",szConfig,1024,CONFIG_PATH);
	m_sstrAppKey = szConfig;
  
	ZeroMemory(szConfig,1024*sizeof(char));
	::GetPrivateProfileStringA("Config","AppSecret","",szConfig,1024,CONFIG_PATH);
	m_sstrAppSecret = szConfig;

	ZeroMemory(szConfig,1024*sizeof(char));
	::GetPrivateProfileStringA("Config","AccessKey","",szConfig,1024,CONFIG_PATH);
	m_sstrAccessKey = szConfig;

	ZeroMemory(szConfig,1024*sizeof(char));
	::GetPrivateProfileStringA("Config","Openid","",szConfig,1024,CONFIG_PATH);
	m_sstrOpenid = szConfig;

	ZeroMemory(szConfig,1024*sizeof(char));
	::GetPrivateProfileStringA("Config","CallbackUrl","",szConfig,1024,CONFIG_PATH);
	m_sstrCallBackUrl = szConfig;

	m_editAppKey.SetWindowText(Mbcs2Unicode(m_sstrAppKey.c_str()).c_str());
	m_editAppSecret.SetWindowText(Mbcs2Unicode(m_sstrAppSecret.c_str()).c_str());
	m_editCallbackUrl.SetWindowText(Mbcs2Unicode(m_sstrCallBackUrl.c_str()).c_str());
	return TRUE;
}

BOOL CLoginDlg::GetAccessKey()
{
	CWeiboParam oParam;

	std::string c_strCustomKey		= TXWeibo::Param::strCustomKey;
	std::string c_oauthCallback		= TXWeibo::Param::strCallbackUrl;
	std::string c_strCustomSecrect	= TXWeibo::Param::strCustomSecrect;
	std::string c_strTokenKey		= TXWeibo::Param::strTokenKey;
	std::string c_strCode			= TXWeibo::Param::strCode;
	std::string c_strOpenid			= TXWeibo::Param::strOpenid;
	std::string c_strGrantType		= TXWeibo::Param::strGrantType;

	oParam.AddParam(c_strCustomKey.c_str(), m_sstrAppKey.c_str());
	oParam.AddParam(c_strCustomSecrect.c_str(), m_sstrAppSecret.c_str());
	oParam.AddParam(c_oauthCallback.c_str(), m_sstrCallBackUrl.c_str());
	oParam.AddParam(c_strCode.c_str(), m_sstrCode.c_str());
	oParam.AddParam(c_strOpenid.c_str(), m_sstrOpenid.c_str());
	oParam.AddParam(c_strGrantType.c_str(), "authorization_code");
	size_t nSizeReturn = 0;

	string strUrl = "https://open.t.qq.com/cgi-bin/oauth2/access_token";

	char* pRetData = NULL;
	int nLen = 0;
	HTTP_RESULTCODE eHttpCode = SyncRequest(strUrl.c_str(), EHttpMethod_Get, oParam, pRetData,nLen);

	if(eHttpCode != HTTPRESULT_OK || pRetData == NULL)
	{
		return FALSE;
	}
  
	string strResult = pRetData;
 
	ReleaseData(pRetData);

	string strMark1 = "access_token=";
	string strMark2 = "&expires_in=";
	string strMark3 = "&refresh_token=";

	string::size_type nTokenPos = strResult.find(strMark1);
	if (nTokenPos == 0)
	{
		string::size_type nSecrectPos = strResult.find(strMark2);
		if ((nSecrectPos != string::npos) && (nSecrectPos > nTokenPos))
		{
			m_sstrAccessKey = strResult.substr(strMark1.length(), nSecrectPos - strMark1.length());
			//oParam.AddParam(c_strTokenKey.c_str(), m_sstrAccessKey.c_str());
		}
		return TRUE;
	}
	return FALSE;
}

