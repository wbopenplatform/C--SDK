// InputDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TXAPITool.h"
#include "InputDlg.h"


// CInputDlg dialog

IMPLEMENT_DYNAMIC(CInputDlg, CDialog)

CInputDlg::CInputDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInputDlg::IDD, pParent)
{

}

CInputDlg::~CInputDlg()
{
}

void CInputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_CODE, m_strCode);
	DDX_Text(pDX, IDC_OPENID, m_strOpenid);
}


BEGIN_MESSAGE_MAP(CInputDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CInputDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CInputDlg message handlers

void CInputDlg::OnBnClickedOk()
{
    UpdateData(TRUE);

	if(m_strCode.IsEmpty() || m_strCode.IsEmpty())
	{
		MessageBox(L"���벻��Ϊ��");
	}

	OnOK();
}


void CInputDlg::OnEnChangeInput()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
