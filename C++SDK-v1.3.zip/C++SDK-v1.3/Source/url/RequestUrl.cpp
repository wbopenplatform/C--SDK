#include "RequestUrl.h"
#include "Request.h"
//#include "url/Oauth/oauth.h"
//#include "url/Oauth/oauth.c"
//#include "url/Oauth/hash.c"
//#include "url/Oauth/xmalloc.c"

CRequestUrl::CRequestUrl(void)
{
}

CRequestUrl::~CRequestUrl(void)
{
}

CRequestUrl* CRequestUrl::GetInstance()
{
	static CRequestUrl oUrlMgr;
	return &oUrlMgr;
}

std::string CRequestUrl::GetUrl(std::string strUrl, EHttpMethod eHttpMethod, CWeiboParam& oParam, std::string& strPost)
{
	std::string strCustomKey;
	std::string strTokenKey;
	std::string strOpenid;

	oParam.GetAndRemoveKey(strCustomKey, strTokenKey, strOpenid);

	std::string strBaseUrl = GetBaseUrl(strUrl, oParam);

	std::string strNormalize =  NormalrizeUrl(strBaseUrl, eHttpMethod, strCustomKey, strTokenKey, strOpenid, strPost);

	return strNormalize;
}

std::string CRequestUrl::GetPostString(CWeiboParam oParam)
{
	std::string strParam; 
	char* pUrlParam = oParam.GetUrlParamString();
	if(pUrlParam)
	{
		strParam = pUrlParam;
		ReleaseData(pUrlParam);
	}
	return strParam;
}

std::string CRequestUrl::GetBaseUrl(std::string strUrl, CWeiboParam oParam)
{
	std::string strBaseUrl = strUrl;

	char* pUrlParam = oParam.GetUrlParamString();
	if (pUrlParam)
	{
		strBaseUrl += "?";
		strBaseUrl += pUrlParam;
		ReleaseData(pUrlParam);
	}

	return strBaseUrl;
}

std::string CRequestUrl::NormalrizeUrl( std::string strUrl, EHttpMethod eHttpMethod, std::string strCustomKey, 
											std::string strTokenKey, std::string strOpenid, std::string& strPost )
{
	char strTmp[512] = {0};

	std::string strHttpMethod;

	if(eHttpMethod == EHttpMethod_Get)
	{
		strHttpMethod = c_strHttpGet;
	}
	else
	{
		strHttpMethod = c_strHttpPost;
	}
	
	int iType = 2;
 	std::string strNormarizeUrl = "";
	std::string::size_type stPos = strUrl.find("/oauth2/access_token",0);
	if(stPos != std::string::npos)
	{
		iType = 1;
	}

	std::string::size_type stBeg = strUrl.find_first_of('?');
	strPost = strUrl.substr(stBeg + 1);
	strNormarizeUrl = strUrl.substr(0, stBeg);

	switch(iType)
	{
		//����ֻ���Ӳ��ֲ������������ͨ��GetUrlParamString�õ�
	case 1:
		//client_id=APP_KEY&client_secret=APP_SECRET&redirect_uri=url&grant_type=authorization_code&code=CODE
		_snprintf(strTmp, sizeof(strTmp), "&client_id=%s", strCustomKey.c_str());
		break;
	case 2:
		_snprintf(strTmp, sizeof(strTmp), "&oauth_consumer_key=%s&access_token=%s&openid=%s&oauth_version=2.a&scope=all", strCustomKey.c_str(), 
			strTokenKey.c_str(), strOpenid.c_str());
		break;
	default:
		break;
	}
	
	strPost.append(strTmp);

	return strNormarizeUrl;
}